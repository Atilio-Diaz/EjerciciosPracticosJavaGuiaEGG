package main;

import rectangulo.Rectangulo;

public class Guia07EggEjercicio04 {
    public static void main(String[] args) {
        Rectangulo rec1=new Rectangulo();
        rec1.CrearRectangulo();
        rec1.SuperficieRectangulo();
        rec1.PerimetroRectangulo();
        rec1.MostrarRectangulo();
    }
}
