package main;

import operacion.*;

public class Guia07EggEjercicio03 {
    public static void main(String[] args) {
        Operacion n=new Operacion();
        Operacion ms=n.CrearOperacion();
        n.Sumar();
        n.Restar();
        n.Multiplicacion();
        n.Dividir();
    }
}
