package main;
import circunferencia.Circunferencia;
public class Guia07EggEjercicio02{
    public static void main(String[] args){
        Circunferencia radio1=new Circunferencia();
        Circunferencia ms=radio1.crearRadio();
        ms.Area();
        ms.Perimetro();
    }
}