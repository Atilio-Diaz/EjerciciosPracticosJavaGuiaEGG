
package main;

import puntos.Puntos;

public class Guia07EggEjercicioExtra02 {
    public static void main(String[] args) {
        Puntos distancia=new Puntos();
        Puntos ms=distancia.CrearPuntos();
        System.out.println(distancia);
        distancia.calcularDevolver();
    }
}
