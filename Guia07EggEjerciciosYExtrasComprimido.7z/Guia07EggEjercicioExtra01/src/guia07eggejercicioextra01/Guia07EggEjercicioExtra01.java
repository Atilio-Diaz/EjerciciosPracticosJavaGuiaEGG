
package guia07eggejercicioextra01;

import cancion.Cancion;

public class Guia07EggEjercicioExtra01 {

    public static void main(String[] args) {
        Cancion tema=new Cancion();
        Cancion ms=tema.CrearCancion();
        System.out.println(tema);
    }
}
