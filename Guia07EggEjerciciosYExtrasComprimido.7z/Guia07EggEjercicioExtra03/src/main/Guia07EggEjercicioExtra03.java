
package main;

import juego.Juego;

public class Guia07EggEjercicioExtra03 {
    public static void main(String[] args) {
        Juego juego1=new Juego();
        juego1.CargarJugadores();
        juego1.IniciarJuego();
        System.out.println("RESULTADOS "+juego1);
    }
}