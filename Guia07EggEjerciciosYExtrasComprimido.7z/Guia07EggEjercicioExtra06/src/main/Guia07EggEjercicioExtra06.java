
package main;

import rectangulo.Rectangulo;

public class Guia07EggEjercicioExtra06 {
    public static void main(String[] args) {
        Rectangulo rectangulo1=new Rectangulo(4, 6);
        rectangulo1.calcular_area();
    }
}
