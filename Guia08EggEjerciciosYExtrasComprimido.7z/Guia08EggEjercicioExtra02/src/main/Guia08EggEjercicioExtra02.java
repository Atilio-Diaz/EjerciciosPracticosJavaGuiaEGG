package main;

import servicios.NIFServicio;

public class Guia08EggEjercicioExtra02 {

    public static void main(String[] args) {

        NIFServicio nif = new NIFServicio();
        System.out.println("****************");
        System.out.println("GENERADOR DE NIF");
        System.out.println("****************");
        while (true) {
            nif.crearNif();
            nif.mostrar();
        }

    }//este lo ise asi
}
