package servicios;

import entidades.NIF;
import java.util.Scanner;

public class NIFServicio {

    Scanner leer = new Scanner(System.in);

    NIF ms = new NIF();

    public NIF crearNif() {
        System.out.print("DIGITE EL NUMERO DE DNI ");
        boolean logic = true;
        do {
            ms.setDNI(leer.nextLong());
            if (ms.getDNI() <= 99999999 && ms.getDNI() > 0) {
                logic = false;
            } else {
                System.out.println("DNI INVALIDO INTENTE DENUEVO");
                System.out.println("DIGITE EL NUMERO DE DNI");
            }
        } while (logic);
        System.out.println("La letra se creara con relacion al DNI");
        String vector[] = {"T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"};
        ms.setLetra(vector[(int) ms.getDNI() % 23]);
        return ms;
    }

    public void mostrar() {
        int x=0;
        int[] vectorDni = new int[8];
        String cambio = String.valueOf(ms.getDNI());
        for (int i = 0; i < 8; i++) {
            if (i>=8-cambio.length()) {
                vectorDni[i] = Integer.valueOf(cambio.substring(x,x+1));
                x++;
            }
            System.out.print("" + vectorDni[i]);
        }
        System.out.println("-"+ms.getLetra());
    }

}
