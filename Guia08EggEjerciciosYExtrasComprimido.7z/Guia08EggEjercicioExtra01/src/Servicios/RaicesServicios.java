package Servicios;

import entidades.Raices;
import java.util.Scanner;

public class RaicesServicios {

    Scanner leer = new Scanner(System.in);

    Raices ms = new Raices();

    public Raices darValor() {
        System.out.println("*******************************");
        System.out.println("LA ECUACION DE 2° SERA: ax²+bx+c");
        System.out.println("*******************************");
        System.out.print("Dar valor a la variable a: ");
        ms.setA(leer.nextDouble());
        System.out.print("Dar valor a la variable b: ");
        ms.setB(leer.nextDouble());
        System.out.print("Dar valor a la variable c: ");
        ms.setC(leer.nextDouble());
        return ms;

    }

    public double getDiscriminate() {
        double Discriminate = (Math.pow(ms.getB(), 2) - 4 * ms.getA() * ms.getC());
        return Discriminate;
    }

    public boolean tieneRaices() {
        boolean confirmar = (getDiscriminate() > 0);
        return confirmar;
    }

    public boolean tieneRaiz() {
        boolean confirmar = (getDiscriminate() == 0);
        return confirmar;
    }

    public double[] obtenerRaices() {
        double[] resultadoV = new double[2];
        if (tieneRaices() == true) {
            resultadoV[0] = ((-ms.getB() - (Math.sqrt((Math.pow(ms.getB(), 2) - 4 * ms.getA() * ms.getC()))))) / (2 * ms.getA());
            resultadoV[1] = ((-ms.getB() + (Math.sqrt((Math.pow(ms.getB(), 2) - 4 * ms.getA() * ms.getC()))))) / (2 * ms.getA());
        }
        return resultadoV;
    }

    public double obtenerRaiz() {
        double resultado = 0;
        if (tieneRaiz() == true) {
            resultado = ((-ms.getB() - (Math.sqrt((Math.pow(ms.getB(), 2) - 4 * ms.getA() * ms.getC()))))) / (2 * ms.getA());
        } else if (tieneRaices() == false && tieneRaiz() == false) {
            System.out.println("El resultado de la raiz fue nullo porque la discriminante fue: " + getDiscriminate());
        }
        return resultado;
    }

    public void calcular() {
        double[] resultadoV = obtenerRaices();
        if (tieneRaices() == true) {
            System.out.println("La primera ecuacion de 2° es : " + ms.getA() + " * " + resultadoV[0] + "²" + " + " + ms.getB() + "*" + resultadoV[0] + " + " + ms.getC() + " = " + ((ms.getA() * (Math.pow(resultadoV[0], 2))) + ms.getB() * resultadoV[0] + ms.getC()) + " <- DEVERIA SER CERO PARA SER CORRECTA");
            System.out.println("La segunda ecuacion de 2° es : " + ms.getA() + " * " + resultadoV[1] + "²" + " + " + ms.getB() + "*" + resultadoV[1] + " + " + ms.getC() + " = " + ((ms.getA() * (Math.pow(resultadoV[1], 2))) + ms.getB() * resultadoV[1] + ms.getC()) + " <- DEVERIA SER CERO PARA SER CORRECTA");
        } else if (tieneRaiz() == true) {
            System.out.println("La unica solucionara la ecuacio de 2° es : " + ms.getA() + " * " + obtenerRaiz() + "²" + " + " + ms.getB() + "*" + obtenerRaiz() + " + " + ms.getC() + " = " + ((ms.getA() * (Math.pow(obtenerRaiz(), 2))) + ms.getB() * obtenerRaiz() + ms.getC()) + " <- DEVERIA SER CERO PARA SER CORRECTA");
        } else if (tieneRaices() == false && tieneRaiz() == false) {
            System.out.println("NO SE PUEDE RESOLBER LA ECUACION DE 2° CON LOS DATOS INGRESADOS " + resultadoV[0] + "²" + " + " + ms.getB() + "*" + resultadoV[0] + " + " + ms.getC() + " = " + (Math.pow(resultadoV[0], 2) + ms.getB() * resultadoV[0] + ms.getC()) + " <- DEVERIA SER CERO PARA SER CORRECTA");
        }

    }

    public void mostrarDatos() {
        System.out.println("" + ms.toString());
    }
}
