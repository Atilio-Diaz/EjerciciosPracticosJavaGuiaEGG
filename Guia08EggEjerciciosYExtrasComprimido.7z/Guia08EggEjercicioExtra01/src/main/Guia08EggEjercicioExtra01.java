package main;

import Servicios.RaicesServicios;

public class Guia08EggEjercicioExtra01 {

    public static void main(String[] args) {

        RaicesServicios calc = new RaicesServicios();

        calc.darValor();
        System.out.println("DISCRIMINATE ES: " + calc.getDiscriminate());
        System.out.println("ECUACION de 2° TIENE 2 SOLUCIONES: " + calc.tieneRaices());
        System.out.println("ECUACION de 2° TIENE UNA SOLA SOLUCION: " + calc.tieneRaiz());
        double[] resultadoV = calc.obtenerRaices();
        System.out.println("Los resultados de las raices para la ecuacion de 2° son: " + resultadoV[0] + " Y " + resultadoV[1]);
        calc.obtenerRaiz();
        calc.calcular();
        calc.mostrarDatos();
    }
}
