
package main;

import servicios.ArregloServicio;


public class Guia09EggEjercicio03 {
    public static void main(String[] args) {
        double[] arregloA=new double[50];
        double[] arregloB=new double[20];
        ArregloServicio ms=new ArregloServicio();
        ms.inicializarA(arregloA);
        ms.mostrarA(arregloA);
        ms.ordenarA(arregloA);
        ms.inicializarB(arregloA,arregloB);
        ms.mostrarAyB(arregloA,arregloB);
    }
}
