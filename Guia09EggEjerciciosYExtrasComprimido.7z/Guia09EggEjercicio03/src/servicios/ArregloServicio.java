package servicios;

import java.util.Arrays;

public class ArregloServicio {

    public double[] inicializarA(double[] arregloA) {
        double[] arrregloA = new double[arregloA.length];
        for (int i = 0; i < arregloA.length; i++) {
            arregloA[i] = (double) Math.round(Math.random() * arregloA.length * 100d) / 100;
        }

        return arrregloA;
    }

    public void mostrarA(double[] arregloA) {
        System.out.print("EL arregloA original: " + Arrays.toString(arregloA));
        System.out.println("");
    }

    public double[] ordenarA(double[] arregloA) {
        Arrays.sort(arregloA);
        int i = 0, x = arregloA.length - 1;
        double[] vector = new double[arregloA.length];
        while (i < arregloA.length) {
            vector[x] = arregloA[i];
            i++;
            x--;
        }
        arregloA=vector;
        return arregloA;
    }

    public double[] inicializarB(double[] arregloA,double[] arregloB) {
        ordenarA(arregloA);
        for (int i = 0; i < arregloA.length; i++) {
            if (i < 10) {
                arregloB[i] = ordenarA(arregloA)[i];
            }else if (i>9 && i<20) {
                arregloB[i]=0.5;
            }
        }
        return arregloB;
    }
    public void mostrarAyB(double[] arregloA, double[] arregloB){
        System.out.print("EL arregloA ordenado: " + Arrays.toString(ordenarA(arregloA)));
        System.out.println("");
        System.out.print("EL arregloB editada: " + Arrays.toString(arregloB));
        System.out.println("");
    }
    
}
