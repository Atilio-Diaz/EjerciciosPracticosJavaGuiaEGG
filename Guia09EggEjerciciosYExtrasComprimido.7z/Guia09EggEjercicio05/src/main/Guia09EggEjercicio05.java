
package main;

import entidades.Persona;
import servicios.PersonaServicio;

public class Guia09EggEjercicio05 {
    public static void main(String[] args) {
        PersonaServicio ps=new PersonaServicio();
        Persona p1=ps.crearPersona();
        System.out.println("La edad de la persona es: "+ps.calcularEdad(p1));
        Persona p2=ps.crearPersona();
        System.out.println("La persona es menor que la primera persona: "+ps.menorQue(p1,p2));
        ps.mostrarPersona(p1, p2);
    }
}
