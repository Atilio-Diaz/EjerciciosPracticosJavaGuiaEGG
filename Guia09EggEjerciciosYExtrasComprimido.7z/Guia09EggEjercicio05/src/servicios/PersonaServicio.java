package servicios;

import entidades.Persona;
import java.util.Date;
import java.util.Scanner;

public class PersonaServicio {

    Scanner leer = new Scanner(System.in);

    public Persona crearPersona() {
        Persona pc = new Persona();
        System.out.print("Cual es el nombre de la persona: ");
        pc.setNombre(leer.next());
        System.out.print("Ingrese el dia de nacimiento: ");
        int dia = leer.nextInt();
        System.out.print("Ingrese el mes de nacimiento: ");
        int mes = leer.nextInt();
        System.out.print("Ingrese el año de nacimiento: ");
        int año = leer.nextInt();
        Date fechanacimiento = new Date(año - 1900, mes - 1, dia);
        pc.setFechanacimiento(fechanacimiento);
        return pc;
    }

    public int calcularEdad(Persona p1) {
        Date fechaActual = new Date();
        int edad = fechaActual.getYear() - p1.getFechanacimiento().getYear();
        return edad;
    }

    public boolean menorQue(Persona p1, Persona p2) {
        boolean resultado = p1.getFechanacimiento().before(p2.getFechanacimiento());
        return resultado;
    }

    public void mostrarPersona(Persona p1, Persona p2) {
        boolean logic = true;
        while (logic) {
            System.out.println("De que persona desea ver la informacion p1 ó p2 | s salir");
            String opcion = leer.next();
            switch (opcion) {
                case "p1":
                    System.out.println("nombre del a persona: " + p1.getNombre());
                    System.out.println("fecha de nacimientdo: " + p1.getFechanacimiento());
                    break;
                case "p2":
                    System.out.println("nombre del a persona: " + p2.getNombre());
                    System.out.println("fecha de nacimientdo: " + p2.getFechanacimiento());
                    break;
                case "s":
                    logic = false;
                    break;
                default:
                    System.out.println("opcion incorrecta");
            }
        }

    }
}
