
package main;

import java.util.Scanner;
import servicios.CadenaServicio;


public class Guia09EggEjercicio01 {
    
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        System.out.print("Escriba una frase: ");
        CadenaServicio c1=new CadenaServicio();
        c1.mostrarVocales();
        c1.invertirFrase();
        System.out.print("Elije una letra que buscar: ");
        String letra=leer.nextLine();
        c1.vecesRepetido(letra);
        System.out.print("Elije otra frase para comparar su longutud y concatenarla a la primera frase: ");
        String frase = leer.nextLine();
        c1.compararLongitud(frase);
        System.out.println("La frase unida es: "+c1.unirFrases(frase));
        System.out.print("Elija una letra para remplazar la letra A :");
        letra=leer.nextLine();
        System.out.println("La frase edita quedo asi: "+c1.reemplazar(letra));
        System.out.print("Elija otra vez para ver si contiene una letra en la frase original");
        letra=leer.nextLine();
        System.out.println("Contenia la letra?: "+c1.contiene(letra));
        c1.mostrarDatos();
    }
}
