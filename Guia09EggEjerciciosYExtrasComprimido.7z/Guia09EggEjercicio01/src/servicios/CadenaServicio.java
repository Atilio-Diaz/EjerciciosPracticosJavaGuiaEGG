package servicios;

import entidades.Cadena;
import java.util.Scanner;

public class CadenaServicio {

    Scanner leer = new Scanner(System.in);

    Cadena ms = new Cadena(leer.nextLine());
    
    public void mostrarVocales() {
        String frase = ms.getFrase();
        int contador = 0;
        for (int i = 0; i < ms.getLargoFrase(); i++) {
            if ("a".equalsIgnoreCase(frase.substring(i, i + 1)) || "e".equalsIgnoreCase(frase.substring(i, i + 1)) || "i".equalsIgnoreCase(frase.substring(i, i + 1)) || "o".equalsIgnoreCase(frase.substring(i, i + 1)) || "u".equalsIgnoreCase(frase.substring(i, i + 1))) {
                contador++;
            }
        }
        System.out.println("La cantidad de vocales fue: " + contador);

    }

    public void invertirFrase() {
        String invertida = "",frase=ms.getFrase();
        for (int i = ms.getLargoFrase() - 1; i >= 0; i--) {
            invertida += frase.charAt(i);
        }
        System.out.println("La frase invertida fue: " + invertida);
    }

    public void vecesRepetido(String letra) {
        String frase=ms.getFrase();
        int contador=0;
        while (-1<frase.indexOf(letra)) {
            frase=frase.substring(frase.indexOf(letra)+letra.length(),frase.length());
            contador++;
        }
        System.out.println("La letra "+letra +" aparecio: "+contador+" veses");
    }
    public void compararLongitud(String frase){
        Integer num1=frase.length();
        System.out.println("La frase tiene la misma longitud que la primera: "+num1.equals(ms.getLargoFrase()));
        
    }
    public String unirFrases(String frase){
        String fraseunida=ms.getFrase().concat(" "+frase);
        return fraseunida;
    }
    public String reemplazar(String letra){
        String fraseEditada=ms.getFrase().replaceAll("a", letra);
        return fraseEditada;
    }
    public boolean contiene(String letra){
        boolean resultado=ms.getFrase().equalsIgnoreCase(letra);
        return resultado;
    }
    public void mostrarDatos() {
        System.out.println(ms.toString());
    }
}
