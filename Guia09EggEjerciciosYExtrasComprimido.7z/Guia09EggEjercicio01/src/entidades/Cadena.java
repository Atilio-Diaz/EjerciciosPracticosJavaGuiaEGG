
package entidades;

public class Cadena {
    private String frase;
    private int largoFrase;

    public Cadena() {
    }

    public Cadena(String frase) {
        this.frase = frase;
        this.largoFrase = frase.length();
    }

    public String getFrase() {
        return frase;
    }

    public void setFrase(String frase) {
        this.frase = frase;
    }

    public int getLargoFrase() {
        return largoFrase;
    }


    @Override
    public String toString() {
        return "Cadena{" + "frace=" + frase + ", largoFrase=" + largoFrase + '}';
    }
    
}
