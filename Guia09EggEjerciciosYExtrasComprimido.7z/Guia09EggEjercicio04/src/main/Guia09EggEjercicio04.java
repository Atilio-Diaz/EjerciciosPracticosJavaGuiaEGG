
package main;

import java.util.Date;
import servicios.FechaServicio;


public class Guia09EggEjercicio04 {
    public static void main(String[] args) {
        FechaServicio ms=new FechaServicio();
        Date fechanacimiento=ms.fechaNacimiento();
        Date fechaactual=ms.fechaActual();
        System.out.println("La fecha actual es: "+fechaactual);
        System.out.println(""+ms.diferencia(fechanacimiento, fechaactual));
    }
}
