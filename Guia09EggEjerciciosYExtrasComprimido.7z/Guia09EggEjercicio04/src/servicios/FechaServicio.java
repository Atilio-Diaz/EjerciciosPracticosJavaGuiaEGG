package servicios;

import java.util.Date;
import java.util.Scanner;

public class FechaServicio {

    Scanner leer = new Scanner(System.in);

    public Date fechaNacimiento() {
        System.out.print("Cual es el dia de nacimientro: ");
        int dia = leer.nextInt();
        System.out.print("Cual es el mes de nacimiento: ");
        int mes = leer.nextInt()-1;
        System.out.print("Cual es el año de nacimiento: ");
        int anio = leer.nextInt()-1900;
        return  new Date(anio,mes,dia);
    }

    public Date fechaActual() {
        return new Date();
    }
    public int diferencia(Date fechaNacimiento, Date fechaActual) {
        long milisegundosPorAnio = 1000L * 60L * 60L * 24L * 365L;
        long diferenciaMilisegundos = fechaActual.getTime() - fechaNacimiento.getTime();
        int edad = (int) (diferenciaMilisegundos / milisegundosPorAnio);
        return edad;
    }
    public void mostrar(){
        System.out.println();
    }
}
