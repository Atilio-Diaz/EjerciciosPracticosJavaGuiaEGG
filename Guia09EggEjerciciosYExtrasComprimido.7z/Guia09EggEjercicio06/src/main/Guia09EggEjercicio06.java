
package main;

import entidad.Curso;
import servicios.CursoServicio;

public class Guia09EggEjercicio06 {
    public static void main(String[] args) {
        CursoServicio cs=new CursoServicio();
        Curso c1=cs.crearCurso();
        System.out.println("Las ganancias semanales seran: $"+cs.calcularGananciasSemanales(c1));
    }
}
