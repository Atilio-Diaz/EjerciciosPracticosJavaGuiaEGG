package servicios;

import entidad.Curso;
import java.util.Scanner;

public class CursoServicio {

    Scanner leer = new Scanner(System.in);

    public String[] cargarAlumnos(String[] alumnos) {
        for (int i = 0; i < alumnos.length; i++) {
            System.out.print("Cual es el nombre del alumno " + (i + 1) + ": ");
            alumnos[i] = leer.next();
        }
        return alumnos;
    }

    public Curso crearCurso() {
        System.out.print("Cual es el nombre del curso: ");
        String nombreCurso = leer.nextLine();
        System.out.print("Cul es el turno temprano ó tarde: ");
        String turno = leer.nextLine();
        while (!"temprano".equalsIgnoreCase(turno) && !"tarde".equalsIgnoreCase(turno)) {
            System.out.println("TURNO INVALIDO");
            System.out.print("Cul es el turno temprano ó tarde: ");
            turno = leer.nextLine();
        }
        System.out.print("Cuantas horas por dia sera el curso: ");
        int horasPorDia = leer.nextInt();
        while (horasPorDia < 1 || horasPorDia > 5) {
            System.out.println("CANTIDAD DE HORAS INVALIDA");
            System.out.print("Cuantas horas por dia sera el curso: ");
            horasPorDia = leer.nextInt();
        }
        System.out.print("Cuantos dias por semana sera el curso: ");
        int diasPorSemana = leer.nextInt();
        while (diasPorSemana < 1 || diasPorSemana > 6) {
            System.out.println("CANTIDAD DE DIAS POR SEMANA INVALIDO");
            System.out.print("Cuantos dias por semana sera el curso: ");
            diasPorSemana = leer.nextInt();
        }
        System.out.print("Cual sera el precio por hora de las clases del curso: ");
        float precioPorHora = leer.nextFloat();
        String[] alumnos = new String[5];
        cargarAlumnos(alumnos);
        Curso cc = new Curso(nombreCurso, turno, alumnos, horasPorDia, diasPorSemana, precioPorHora);
        return cc;
    }

    public float calcularGananciasSemanales(Curso c1) {
        float ganancias = c1.getDiasPorSemana() * c1.getHorasPorDia() * c1.getPrecioPorHora() * c1.getAlumnos().length;
        return ganancias;
    }
}
