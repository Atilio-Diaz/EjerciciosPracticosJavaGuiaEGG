
package main;

import servicios.ParDeNumerosServicio;


public class Guia09EggEjercicio02 {
    public static void main(String[] args) {
        ParDeNumerosServicio calc1=new ParDeNumerosServicio();
        calc1.mostrarValores();
        System.out.println("El numero mayor fue: "+calc1.devolverMayor());
        System.out.println("El numero mayor(redondeado) potenciado por el numero menor(redondeado) fue: "+calc1.calcularPotencia());
        System.out.println("La raiz del valor absoluto del menor de los numeros fue: "+calc1.CalcularRaiz());
    }
}
