
package servicios;

import entidades.ParDeNumeros;


public class ParDeNumerosServicio {
    ParDeNumeros ms=new ParDeNumeros();
    public void mostrarValores(){
        System.out.println("numero1: "+ms.getNumero1());
        System.out.println("numero2: "+ms.getNumero2());
    }
    public double devolverMayor(){
        double resultado=Math.max(ms.getNumero1(), ms.getNumero2());
        return resultado;
    }
    public double devolverMenor(){
        double resultado=Math.min(ms.getNumero1(), ms.getNumero2());
        return resultado;
    }
    public double calcularPotencia(){
        double potencia=Math.pow(Math.round(devolverMayor()),Math.round(devolverMenor()));
        return potencia;
    }
    public double CalcularRaiz(){
        double raiz=Math.sqrt(Math.abs(devolverMenor()));
        return raiz;
    }
    
}
