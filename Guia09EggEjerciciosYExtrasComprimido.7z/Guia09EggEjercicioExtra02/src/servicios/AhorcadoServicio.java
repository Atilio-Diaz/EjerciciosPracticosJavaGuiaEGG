package servicios;

import entidades.Ahorcado;
import java.util.Arrays;
import java.util.Scanner;

public class AhorcadoServicio {

    Scanner leer = new Scanner(System.in);

    Ahorcado j1 = new Ahorcado();

    public Ahorcado crearJuego() {

        System.out.print("INGRESE UNA PALABRA: ");
        String palabraIn = leer.nextLine();
        String[] vector = new String[palabraIn.length()];
        for (int i = 0; i < palabraIn.length(); i++) {
            vector[i] = palabraIn.substring(i, i + 1);
        }
        j1.setPalabra(vector);
        System.out.print("Cual sera el maximo de oportunidades: ");
        j1.setJugadasMax(leer.nextInt());
        j1.setLetrasEncontradas(0);
        return new Ahorcado();
    }

    public void longitud() {
        System.out.println("El largo de la palabra es: " + j1.getPalabra().length);
    }

    public int buscar(String letra) {
        String[] palabra = j1.getPalabra();
        int contador = 0;
        int lEncontradas = 0;
        for (int i = 0; i < palabra.length; i++) {
            if (letra.equalsIgnoreCase(palabra[i])) {
                System.out.println("Acertaste la letra: { " + letra + " } se encontro en la palabra en la pocicion: " + i);
                contador++;
                lEncontradas++;
            }

        }
        if (contador == 0) {
            System.out.println("NO SE encontro la Letra");
        }
        return lEncontradas;
    }

    public boolean encontradas(String letra) {

        boolean resultado = false;

        String[] palabra = j1.getPalabra();
        for (int i = 0; i < j1.getPalabra().length; i++) {
            if (letra.equalsIgnoreCase(palabra[i])) {
                resultado = true;

            }
        }

        return resultado;
    }

    public void intentos(int intentos) {
        System.out.println("Tequedan: " + intentos + " intentos");
    }

    public void juego() {
        crearJuego();
        longitud();
        String letra;
        int intentos = j1.getJugadasMax();
        int lEncontradas = 0;
        boolean confirmar;
        String[] vectorM = new String[j1.getPalabra().length];
        Arrays.fill(vectorM, "");
        while (intentos > 0 && lEncontradas < j1.getPalabra().length) {
            System.out.print("Elije una letra para buscar en el AHORCADO: ");
            letra = leer.next();
            lEncontradas += buscar(letra);
            confirmar = encontradas(letra);
            for (int i = 0; i < j1.getPalabra().length; i++) {
                if (confirmar == true && letra.equalsIgnoreCase(j1.getPalabra()[i])) {
                    vectorM[i] = letra;
                }

            }
            if (confirmar == false) {

                intentos--;
                intentos(intentos);
            } else if (lEncontradas == j1.getPalabra().length) {
                System.out.println("\t ****************");
                System.out.println("\t ¡¡¡¡¡GANASTE!!!!");
                System.out.println("\t ****************");
            }
            System.out.println("\t   " + Arrays.toString(vectorM));
        }
        if (intentos == 0) {
            System.out.println("AHORCADO");
        }
    }
}
