
package main;

import servicios.AhorcadoServicio;


public class Guia09EggEjercicioExtra02 {
    public static void main(String[] args) {
        AhorcadoServicio ahs=new AhorcadoServicio();
        ahs.juego();
    }
}
