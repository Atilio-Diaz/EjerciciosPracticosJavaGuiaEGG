package service;

import entidad.JuegoAdivinarMes;
import java.util.Scanner;

public class JuegoAdivinarMesServicio {

    Scanner leer = new Scanner(System.in);

    JuegoAdivinarMes ms = new JuegoAdivinarMes();

    public void adivinar() {
        String[] mes = ms.getMeses();
        String mesSecreto = "";
        int azar = (int) (Math.random() * ms.getMeses().length);
        for (int i = 0; i < mes.length; i++) {
            if (i == azar) {
                mesSecreto = mes[i];
            }
        }

        boolean logic = true;
        do {
            System.out.println("Adivina el mes sectreto: ");
            String eleccion = leer.next();
            if (eleccion.equalsIgnoreCase(mesSecreto)) {
                System.out.println("ACERTASTE");
                logic = false;
            } else if ("t".equalsIgnoreCase(eleccion)) {
                System.out.println("tramposo: " + mesSecreto);
            } else {
                System.out.println("VUELVE A INTENTAR");
            }
        } while (logic);

    }
}
