package entidad;

public class JuegoAdivinarMes {

    private String[] meses;

    public JuegoAdivinarMes() {
        this.meses = new String[]{"enero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "nobiembre", "diciembre"};
    }

    public String[] getMeses() {
        return meses;
    }

    public void setMeses(String[] meses) {
        this.meses = meses;
    }

}
