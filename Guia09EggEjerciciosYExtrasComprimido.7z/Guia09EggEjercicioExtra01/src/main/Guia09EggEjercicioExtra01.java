package main;

import service.JuegoAdivinarMesServicio;

public class Guia09EggEjercicioExtra01 {

    public static void main(String[] args) {

        JuegoAdivinarMesServicio j1 = new JuegoAdivinarMesServicio();
        j1.adivinar();
    }
}
